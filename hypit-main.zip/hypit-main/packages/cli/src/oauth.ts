import { createHash, randomBytes } from "node:crypto";
import { createServer } from "node:http";
import { spawn } from "node:child_process";

import type { CredentialAcquisition } from "@hypit/runtime";
import { encodeOAuth2Credential } from "@hypit/runtime";

const CALLBACK_MARK_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true"><path d="M7.6 3.8H14.6L12.6 7.2H5.6L7.6 3.8Z" fill="currentColor"/><path d="M4.1 10.4H16.6L18.7 7H30.4L27.9 11.1H16.1L14.1 14.2H1.8L4.1 10.4Z" fill="currentColor"/><path d="M19.1 14.1H23.1L19.3 20.7H15.4L19.1 14.1Z" fill="currentColor"/></svg>`;

type OAuthAcquisitionOptions = {
  readonly onProgress?: (message: string) => void;
  readonly fetch?: typeof globalThis.fetch;
  readonly open?: (url: string) => void;
};

function base64url(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString("base64").replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

function positiveNumber(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;
}

function tokenExpiry(value: { readonly expires_at?: unknown; readonly expires_in?: unknown }): number | undefined {
  const absolute = positiveNumber(value.expires_at);
  if (absolute !== undefined) return absolute > 10_000_000_000 ? absolute : absolute * 1_000;
  const seconds = positiveNumber(value.expires_in);
  return seconds === undefined ? undefined : Date.now() + seconds * 1_000;
}

export type AuthorizeBrowserLaunch = {
  readonly command: string;
  readonly args: readonly string[];
  readonly windowsVerbatimArguments: boolean;
  readonly env?: Readonly<Record<string, string>>;
};

/**
 * Open the authorize URL in a browser. Windows `cmd /c start` treats `&` as a command
 * separator unless the URL is a later quoted token after an explicit window title.
 */
export function authorizeBrowserLaunch(
  url: string,
  options: { readonly platform?: NodeJS.Platform; readonly comSpec?: string } = {},
): AuthorizeBrowserLaunch {
  const platform = options.platform ?? process.platform;
  if (platform === "win32") {
    // Expand one environment value after cmd parses the command. Interpolating the
    // URL into command text would also expand percent sequences inside the URL.
    const serialized = new URL(url).href;
    return {
      command: options.comSpec ?? process.env.ComSpec ?? "cmd.exe",
      args: ["/d", "/s", "/v:off", "/c", 'start "" "%HYPIT_OAUTH_AUTHORIZE_URL%"'],
      windowsVerbatimArguments: true,
      env: { HYPIT_OAUTH_AUTHORIZE_URL: serialized },
    };
  }
  return {
    command: platform === "darwin" ? "open" : "xdg-open",
    args: [url],
    windowsVerbatimArguments: false,
  };
}

function openAuthorizeUrl(url: string): void {
  const launch = authorizeBrowserLaunch(url);
  const child = spawn(launch.command, [...launch.args], {
    stdio: "ignore",
    detached: true,
    windowsHide: true,
    windowsVerbatimArguments: launch.windowsVerbatimArguments,
    ...(launch.env === undefined ? {} : { env: { ...process.env, ...launch.env } }),
  });
  // A missing opener must not crash the CLI; the URL is already on the progress line.
  child.once("error", () => undefined);
  child.unref();
}

/** Acquire one OAuth credential from the exact data declared by its Endpoint instance. */
export async function acquireOAuthCredential(
  acquisition: CredentialAcquisition,
  options: OAuthAcquisitionOptions = {},
): Promise<string> {
  if (!Number.isSafeInteger(acquisition.requestTimeoutMs) || acquisition.requestTimeoutMs <= 0) {
    throw new Error("OAuth token request timeout must be a positive integer");
  }
  const verifier = base64url(randomBytes(32));
  // S256 is part of OAuth PKCE. It authenticates this browser exchange; it is not content identity.
  const challenge = base64url(createHash("sha256").update(verifier).digest());
  const callbackOrigin = new URL(acquisition.redirectUri).origin;
  const nonce = base64url(randomBytes(24));
  let state = nonce;
  const server = createServer();
  const callback = new Promise<string>((resolveCode, reject) => {
    let settled = false;
    const closeAllConnections = (): void => {
      server.closeAllConnections?.();
      server.unref();
    };
    server.on("request", (request, response) => {
      // The hosted callback page fetches this loopback from a public page; Chrome's Private
      // Network Access check preflights with OPTIONS and expects these headers back.
      if (request.method === "OPTIONS") {
        response.writeHead(204, {
          "access-control-allow-origin": callbackOrigin,
          "access-control-allow-methods": "GET, OPTIONS",
          "access-control-allow-private-network": "true",
          "cache-control": "no-store",
          connection: "close",
        });
        response.end();
        return;
      }
      if (settled) {
        response.writeHead(204, { "cache-control": "no-store", connection: "close" });
        response.end();
        return;
      }
      try {
        const url = new URL(request.url ?? "/", "http://127.0.0.1");
        if (url.pathname !== "/callback") throw new Error("unexpected OAuth callback path");
        if (url.searchParams.get("state") !== state) throw new Error("OAuth state mismatch");
        const authorizationError = url.searchParams.get("error");
        if (authorizationError !== null) throw new Error(`OAuth authorization failed: ${authorizationError}`);
        const code = url.searchParams.get("code");
        if (code === null || code.length === 0) throw new Error("OAuth callback contained no code");
        response.writeHead(200, {
          "access-control-allow-origin": callbackOrigin,
          "cache-control": "no-store",
          connection: "close",
          "content-type": "text/html; charset=utf-8",
        });
        response.end(callbackPage(true), closeAllConnections);
        settled = true;
        resolveCode(code);
      } catch (error) {
        response.writeHead(400, {
          "access-control-allow-origin": callbackOrigin,
          "cache-control": "no-store",
          connection: "close",
          "content-type": "text/html; charset=utf-8",
        });
        response.end(callbackPage(false), closeAllConnections);
        settled = true;
        reject(error);
      } finally {
        server.close();
        server.closeIdleConnections?.();
        server.unref();
      }
    });
    server.once("error", reject);
  });
  await new Promise<void>((resolveListen, rejectListen) => {
    server.listen(0, "127.0.0.1", () => resolveListen());
    server.once("error", rejectListen);
  });
  const address = server.address();
  if (address === null || typeof address === "string") throw new Error("could not open a local OAuth callback");
  // The hosted callback page forwards the code to this port when the browser shares this host;
  // otherwise the page shows `code#state` for the user to deliver to this port themselves.
  state = `${nonce}.${address.port}`;
  const redirectUri = acquisition.redirectUri;
  const authorize = new URL(acquisition.authorizationEndpoint);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("client_id", acquisition.clientId);
  authorize.searchParams.set("redirect_uri", redirectUri);
  authorize.searchParams.set("scope", acquisition.scopes.join(" "));
  authorize.searchParams.set("state", state);
  authorize.searchParams.set("code_challenge", challenge);
  authorize.searchParams.set("code_challenge_method", "S256");
  options.onProgress?.(`Opening sign-in: ${authorize}`);
  if (options.open === undefined) openAuthorizeUrl(authorize.toString());
  else options.open(authorize.toString());
  const code = await callback;
  options.onProgress?.("Authorization returned. Exchanging token…");
  const deadline = AbortSignal.timeout(acquisition.requestTimeoutMs);
  let tokenResponse: Response;
  let body: string;
  try {
    tokenResponse = await (options.fetch ?? globalThis.fetch)(acquisition.tokenEndpoint, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
        client_id: acquisition.clientId,
        code_verifier: verifier,
      }),
      signal: deadline,
    });
    body = await tokenResponse.text();
  } catch (error) {
    if (deadline.aborted) {
      throw new Error(
        `OAuth authorization returned, but the token exchange timed out after ${acquisition.requestTimeoutMs} ms; no credential was stored`,
        { cause: error },
      );
    }
    throw error;
  }
  if (!tokenResponse.ok) throw new Error(`OAuth token exchange failed (${tokenResponse.status}): ${body.slice(0, 200)}`);
  const parsed = JSON.parse(body) as {
    readonly access_token?: unknown;
    readonly refresh_token?: unknown;
    readonly expires_at?: unknown;
    readonly expires_in?: unknown;
  };
  if (typeof parsed.access_token !== "string" || parsed.access_token.length === 0) {
    throw new Error("OAuth token response contained no access token");
  }
  options.onProgress?.("Token received. Saving credential…");
  const expiresAt = tokenExpiry(parsed);
  return encodeOAuth2Credential({
    accessToken: parsed.access_token,
    ...(typeof parsed.refresh_token === "string" && parsed.refresh_token.length > 0
      ? { refreshToken: parsed.refresh_token }
      : {}),
    ...(expiresAt === undefined ? {} : { expiresAt }),
  });
}

function callbackPage(success: boolean): string {
  const title = success ? "Authorization received" : "Hypit sign-in failed";
  const heading = success ? "Authorization received" : "Hypit sign-in failed";
  const message = success
    ? "Return to the terminal while Hypit finishes the token exchange and stores the credential."
    : "The sign-in could not be completed. You can close this window and try again.";
  const tone = success ? "success" : "error";
  const favicon = `data:image/svg+xml,${encodeURIComponent(CALLBACK_MARK_SVG)}`;
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <link rel="icon" href="${favicon}">
    <title>${title}</title>
    <style>
      :root {
        color-scheme: light dark;
        --accent: #de3b67;
        --ink: #1b1a18;
        --muted: #6b6963;
        --line: #e5e2dd;
        --paper: #fff;
        --gutter: 80px;
        --bad: #b8352a;
        font-family: "Hanken Grotesk", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      }
      * { box-sizing: border-box; }
      html { min-width: 320px; }
      body { min-height: 100vh; margin: 0; display: flex; flex-direction: column; color: var(--ink); background: var(--paper); -webkit-font-smoothing: antialiased; }
      .site-header { height: 64px; flex: 0 0 64px; border-bottom: 1px solid var(--line); }
      .shell { width: 100%; max-width: 1440px; height: 100%; margin: 0 auto; padding-inline: var(--gutter); display: flex; align-items: center; }
      .brand { display: inline-flex; align-items: center; gap: 8px; color: var(--ink); font-size: 20px; font-weight: 650; letter-spacing: -.04em; }
      .brand svg { width: 28px; height: 28px; color: var(--accent); }
      main { flex: 1 1 auto; display: grid; place-items: center; padding: clamp(64px, 11vh, 144px) var(--gutter) clamp(72px, 12vh, 160px); }
      .hero { width: min(100%, 720px); text-align: center; }
      .status { display: flex; justify-content: center; margin-bottom: 28px; color: var(--accent); }
      .status.error { color: var(--bad); }
      .mark { width: 56px; height: 56px; display: grid; place-items: center; border: 1px solid currentColor; border-radius: 8px; }
      .mark svg { width: 32px; height: 32px; }
      h1 { margin: 0; font-size: clamp(38px, 5vw, 62px); font-weight: 600; line-height: 1.18; letter-spacing: -2px; }
      p { max-width: 540px; margin: 20px auto 0; color: var(--muted); font-size: clamp(17px, 1.6vw, 22px); line-height: 1.5; }
      @media (prefers-color-scheme: dark) {
        :root { --paper: #14110f; --ink: #e9e5db; --muted: #e9e5dba8; --line: #e9e5db1c; --accent: #de3c66; --bad: #ef8378; }
      }
      @media (max-width: 767px) { :root { --gutter: 20px; } main { padding-top: 64px; padding-bottom: 80px; } }
      @media (prefers-reduced-motion: reduce) { * { transition-duration: .01ms !important; animation-duration: .01ms !important; } }
    </style>
  </head>
  <body>
    <header class="site-header">
      <div class="shell"><div class="brand">${CALLBACK_MARK_SVG}<span>hypit</span></div></div>
    </header>
    <main>
      <section class="hero" aria-labelledby="callback-heading">
        <div class="status ${tone}">
          <span class="mark" aria-hidden="true">
            ${success ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 6 18 18M18 6 6 18"/></svg>'}
          </span>
        </div>
        <h1 id="callback-heading">${heading}</h1>
        <p>${message}</p>
      </section>
    </main>
  </body>
</html>`;
}
