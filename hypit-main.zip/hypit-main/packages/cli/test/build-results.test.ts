import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, readdir, realpath, rm, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { commandHint } from "../src/command-hint.js";
import test from "node:test";

import {
  fileReferenceIdentity,
  FileBuildResult,
  FileBuildResultRepository,
  ownedFileReference,
} from "@hypit/result/node";
import { ModulePackageRegistry, Compiler } from "@hypit/compiler";
import { AuthorFrontendRegistry, sealGraphFragment } from "@hypit/author";
import { createMarkupAuthorFrontend, MarkupSurfaceRegistry } from "@hypit/markup";
import type { BuildState, ModuleManifest, ProducerRef, TypeRef } from "@hypit/protocol";
import { runMarkupFrontend } from "@hypit/markup/run";
import { NodeFilesystemWorkspace } from "@hypit/workspace/node";

import type { CliDistribution } from "../src/distribution.js";
import { createCatalogDescriptor } from "../src/build-planning.js";
import { runCli } from "../src/main.js";
import { loadRunFile, resolveBuildResultValue } from "../src/run-file.js";

const valueType: TypeRef = {
  module: { name: "example.result", version: "1" },
  name: "Value",
};

function completedState(): BuildState {
  return {
    status: "complete",
    records: [{ id: "record:stage", type: valueType, value: { kind: "inline", value: "ready" } }],
    plan: {
      outputBindings: [{ output: "logical:stage", record: "record:stage", type: valueType }],
    },
  } as unknown as BuildState;
}

async function fixture(root: string, id = "bld_20260902T110000000Z_0000000001", source = "main.svml"): Promise<void> {
  const result = await FileBuildResult.create(join(root, ".hypit", "results"), {
    id,
    title: "episode-stage",
    source: { id: source },
    run: { id: "build.svrun" },
    targets: ["stage.value"],
    publishedOutputs: [{ name: "stage.value", output: "logical:stage" }],
  });
  await result.sync({
    state: completedState(),
    resources: { async open() { throw new Error("inline Result has no files"); } },
  });
  await result.finish({ outcome: "complete" });
}

function resultDistribution(): CliDistribution {
  return {
    async openProjectResults(projectRoot: string) {
      return {
        location: {
          root: projectRoot,
          selection: { use: "test.results", config: {} },
        },
        repository: new FileBuildResultRepository(join(projectRoot, ".hypit", "results")),
        close() {},
      };
    },
    async diagnoseProjectResults() { return { diagnostics: [] }; },
  } as unknown as CliDistribution;
}

async function jsonCommand(args: readonly string[], root: string): Promise<unknown> {
  let output = "";
  await runCli([...args, "--project", root, "--json"], {
    write(text) { output += text; },
  }, resultDistribution());
  return JSON.parse(output);
}

async function humanCommand(args: readonly string[], root: string): Promise<string> {
  let output = "";
  await runCli([...args, "--project", root], {
    write(text) { output += text; },
  }, resultDistribution());
  return output;
}

test("builds, history, inspect and get read project Build Results without opening a Runtime", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-results-"));
  try {
    await fixture(root);
    await writeFile(join(root, ".hypit", "runtime"), "missing-runtime.json\n", "utf8");
    const builds = await jsonCommand(["builds"], root) as {
      readonly builds: readonly {
        readonly id: string;
        readonly title?: string;
        readonly outcome: string;
        readonly outputCount: number;
      }[];
    };
    assert.equal(builds.builds.length, 1);
    assert.equal(builds.builds[0]?.id, "bld_20260902T110000000Z_0000000001");
    assert.equal(builds.builds[0]?.title, "episode-stage");
    assert.equal(builds.builds[0]?.outcome, "complete");
    assert.equal(builds.builds[0]?.outputCount, 1);
    assert.equal("source" in builds.builds[0]!, false);
    assert.equal("outputs" in builds.builds[0]!, false);

    const history = await jsonCommand(["history", "stage.value"], root) as {
      readonly entries: readonly { readonly build: string; readonly output: { readonly name: string } }[];
    };
    assert.equal(history.entries.length, 1);
    assert.equal(history.entries[0]?.build, "bld_20260902T110000000Z_0000000001");
    assert.equal(history.entries[0]?.output.name, "stage.value");

    const inspected = await jsonCommand(["inspect", "bld_20260902T110000000Z_0000000001"], root) as {
      readonly build: { readonly id: string; readonly title?: string };
    };
    assert.equal(inspected.build.id, "bld_20260902T110000000Z_0000000001");
    assert.equal(inspected.build.title, "episode-stage");

    const humanHistory = await humanCommand(["history", "stage.value"], root);
    assert.match(humanHistory, /episode-stage/u);
    assert.doesNotMatch(humanHistory, /example\.result|scalar/u);

    const humanInspect = await humanCommand(["inspect", "bld_20260902T110000000Z_0000000001"], root);
    assert.match(humanInspect, /Target\s+stage\.value/u);
    assert.doesNotMatch(humanInspect, /example\.result|scalar/u);

    const destination = join(root, "exported.json");
    const exported = await jsonCommand([
      "get", "bld_20260902T110000000Z_0000000001", "--output", "stage.value", "--to", destination,
    ], root);
    assert.deepEqual(exported, {
      format: "hypit.cli-get@1",
      build: "bld_20260902T110000000Z_0000000001",
      output: "stage.value",
      type: "example.result@1/Value",
      kind: "scalar",
      path: destination,
    });
    assert.equal(await readFile(destination, "utf8"), "\"ready\"\n");

    const humanDestination = join(root, "human-exported.json");
    const humanGet = await humanCommand([
      "get", "bld_20260902T110000000Z_0000000001", "--output", "stage.value", "--to", humanDestination,
    ], root);
    assert.match(humanGet, /Exported stage\.value → human-exported\.json/u);
    assert.doesNotMatch(humanGet, /\b(?:Type|Kind|Build)\b|example\.result|scalar/u);
    await assert.rejects(
      jsonCommand(["get", "bld_20260902T110000000Z_0000000001", "--output", "stage.value", "--to", destination], root),
      /Export destination .* already exists/u,
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("history scans older pages for matches and compares project-relative source paths", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-history-"));
  try {
    await fixture(root);
    const repository = new FileBuildResultRepository(join(root, ".hypit", "results"));
    for (const id of [
      "bld_20260902T110000001Z_0000000001",
      "bld_20260902T110000002Z_0000000001",
    ]) {
      const writer = await repository.create({
        id,
        source: { id: "other.svml" },
        targets: [],
        publishedOutputs: [],
      });
      await writer.finish({ outcome: "failed", failure: "fixture without the requested Output" });
    }

    const history = await jsonCommand([
      "history", "stage.value", "--source", join(root, "main.svml"), "--limit", "1",
    ], root) as {
      readonly source: string;
      readonly entries: readonly { readonly build: string }[];
    };
    assert.equal(history.source, "main.svml");
    assert.deepEqual(history.entries.map((item) => item.build), ["bld_20260902T110000000Z_0000000001"]);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("get exports Resource bytes and a self-contained Composite directory", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-get-"));
  const build = "bld_20260902T110000010Z_0000000001";
  const videoType = { module: { name: "example.media", version: "1" }, name: "Video" } satisfies TypeRef;
  const compositeType = { module: { name: "example.speech", version: "1" }, name: "CompositeValue" } satisfies TypeRef;
  const bytes = new TextEncoder().encode("video bytes");
  const video = {
    kind: "blob",
    resource: "res_video",
    size: bytes.byteLength,
    mediaType: "video/mp4",
  } as const;
  try {
    const result = await FileBuildResult.create(join(root, ".hypit", "results"), {
      id: build,
      source: { id: join(root, "main.svml") },
      targets: ["final.video"],
      publishedOutputs: [
        { name: "final.video", output: "logical:video" },
        { name: "final.take", output: "logical:take" },
      ],
    });
    await result.sync({
      state: {
        status: "complete",
        records: [
          { id: "record:video", type: videoType, value: video },
          {
            id: "record:take",
            type: compositeType,
            value: { kind: "inline", value: { words: ["hello"], media: { artifact: video } } },
          },
        ],
        plan: { outputBindings: [
          { output: "logical:video", record: "record:video", type: videoType },
          { output: "logical:take", record: "record:take", type: compositeType },
        ] },
      } as unknown as BuildState,
      resources: {
        async open() { return (async function* () { yield bytes; })(); },
      },
    });
    await result.finish({ outcome: "complete" });

    const inspected = await jsonCommand([
      "inspect", build, "--output", "final.take",
    ], root) as {
      readonly build: { readonly outputs: readonly [{ readonly name: string; readonly kind: string }] };
    };
    assert.equal(inspected.build.outputs[0].name, "final.take");
    assert.equal(inspected.build.outputs[0].kind, "composite");
    assert.equal("value" in inspected.build.outputs[0], false);
    assert.equal("path" in inspected.build.outputs[0], false);

    const resourceDestination = join(root, "output", "final.mp4");
    const resource = await jsonCommand([
      "get", build, "--output", "final.video", "--to", resourceDestination,
    ], root) as { readonly kind: string; readonly build: string; readonly output: string };
    assert.equal(resource.kind, "resource");
    assert.equal(resource.build, build);
    assert.equal(resource.output, "final.video");
    assert.equal(new TextDecoder().decode(await readFile(resourceDestination)), "video bytes");

    const compositeDestination = join(root, "output", "final-take");
    const composite = await jsonCommand([
      "get", build, "--output", "final.take", "--to", compositeDestination,
    ], root) as { readonly kind: string; readonly path: string };
    assert.equal(composite.kind, "composite");
    assert.equal(composite.path, compositeDestination);
    assert.equal((await stat(compositeDestination)).isDirectory(), true);
    const document = JSON.parse(await readFile(join(compositeDestination, "value.json"), "utf8")) as {
      readonly format: string;
      readonly value: { readonly words: readonly string[]; readonly media: { readonly artifact: null } };
      readonly resources: readonly [{ readonly file: { readonly path: string } }];
    };
    assert.equal(document.format, "hypit.result-value@1");
    assert.deepEqual(document.value.words, ["hello"]);
    assert.equal(document.value.media.artifact, null);
    assert.equal(
      new TextDecoder().decode(await readFile(join(compositeDestination, document.resources[0].file.path))),
      "video bytes",
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("get requires an exact Output name and an explicit destination", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-get-options-"));
  try {
    const silent = { write() {} };
    await assert.rejects(
      runCli(["get", "bld_20260902T110000000Z_0000000001", "--project", root], silent, resultDistribution()),
      /get requires --output/u,
    );
    await assert.rejects(
      runCli([
        "get", "bld_20260902T110000000Z_0000000001", "--output", "stage.value", "--project", root,
      ], silent, resultDistribution()),
      /get requires --to/u,
    );
    await assert.rejects(
      runCli(["history", "--source", join(root, "main.svml"), "--project", root], silent,
        resultDistribution()),
      /history requires one exact Output name/u,
    );
    await assert.rejects(
      runCli(["history", "stage.value", "--pin", "--project", root], silent, resultDistribution()),
      /unknown option --pin/u,
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("result edit changes only the exact project Result presentation without opening a Runtime", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-result-edit-"));
  try {
    await fixture(root);
    const edited = await jsonCommand([
      "result", "edit", "bld_20260902T110000000Z_0000000001",
      "--title", "Episode 12 B-roll",
      "--note", "Use the close-up for the opening beat.",
      "--highlight", "stage.value",
      "--highlight", "stage.value",
    ], root) as {
      readonly build: string;
      readonly title: string;
      readonly note: string;
      readonly highlightedOutputs: readonly string[];
    };
    assert.deepEqual(edited, {
      format: "hypit.cli-result-edit@1",
      build: "bld_20260902T110000000Z_0000000001",
      title: "Episode 12 B-roll",
      note: "Use the close-up for the opening beat.",
      highlightedOutputCount: 1,
      highlightedOutputs: ["stage.value"],
    });

    const repository = new FileBuildResultRepository(join(root, ".hypit", "results"));
    const stored = await repository.read("bld_20260902T110000000Z_0000000001");
    assert.equal(stored?.title, "Episode 12 B-roll");
    assert.equal(stored?.note, "Use the close-up for the opening beat.");
    assert.deepEqual(stored?.highlightedOutputs, ["stage.value"]);

    const cleared = await jsonCommand([
      "result", "edit", "bld_20260902T110000000Z_0000000001", "--clear-title", "--clear-note", "--clear-highlights",
    ], root) as {
      readonly title: null;
      readonly note: null;
      readonly highlightedOutputCount: number;
      readonly highlightedOutputs: readonly string[];
    };
    assert.equal(cleared.title, null);
    assert.equal(cleared.note, null);
    assert.equal(cleared.highlightedOutputCount, 0);
    assert.deepEqual(cleared.highlightedOutputs, []);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("build-record selects one exact Result Output without leaking its storage address into Core", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-result-reuse-"));
  try {
    const module = { name: "example.result-reuse", version: "1" } as const;
    const videoType = { module, name: "Video" } satisfies TypeRef;
    const producer = { module, name: "make-video" } satisfies ProducerRef;
    const manifest: ModuleManifest = {
      format: "hypit.module@1",
      name: module.name,
      version: module.version,
      dependencies: [],
      types: [{ name: videoType.name }],
      capabilities: [],
      producers: [{
        name: producer.name,
        inputs: [],
        outputs: [{ name: "video", type: videoType }],
        needs: [],
      }],
    };
    const fragment = sealGraphFragment({
      inputs: [],
      operations: [{
        id: "make-video",
        producer,
        inputs: {},
        result: { kind: "output", name: "video" },
      }],
      exports: [{
        name: "video",
        type: videoType,
        root: { kind: "fragment-operation", operation: "make-video" },
      }],
    });
    const modules = new ModulePackageRegistry();
    modules.register({ manifest });
    const surfaces = new MarkupSurfaceRegistry();
    surfaces.registerStructured({
      module,
      declaration: { name: "video", tag: "Video", mode: "structured", outputs: [] },
      handler: ({ element }) => {
        const id = element.attributes.id;
        if (typeof id !== "string") throw new Error("Video id is required");
        return {
          records: [],
          components: [{ id, fragment: fragment.id, inputs: {}, outputs: { video: `${id}.video` }, range: element.range }],
          fragments: [fragment],
        };
      },
    });
    const authorFrontends = new AuthorFrontendRegistry();
    authorFrontends.register(createMarkupAuthorFrontend({
      registry: surfaces,
      resolveModule(request) {
        const resolved = modules.resolve(request.from);
        if (resolved === undefined) throw new Error(`unknown module ${request.from}`);
        return resolved;
      },
    }));
    const authorCompiler = new Compiler({
      modules,
      frontends: authorFrontends,
      workspace: new NodeFilesystemWorkspace({ root }),
    });

    const resultsRoot = join(root, ".hypit", "results");
    const result = await FileBuildResult.create(resultsRoot, {
      id: "bld_20260902T110000001Z_0000000001",
      source: { id: join(root, "main.svml") },
      run: { id: join(root, "prior.svrun") },
      targets: ["shot.video"],
      publishedOutputs: [{ name: "shot.video", output: "logical:video" }],
    });
    const bytes = new TextEncoder().encode("prior video bytes");
    await result.sync({
      state: {
        status: "complete",
        records: [{
          id: "record:video",
          type: videoType,
          value: { kind: "inline", value: { artifact: {
            kind: "blob",
            resource: "res_prior_video",
            size: bytes.byteLength,
            mediaType: "video/mp4",
          } } },
        }],
        plan: { outputBindings: [{ output: "logical:video", record: "record:video", type: videoType }] },
      } as unknown as BuildState,
      resources: {
        async open() {
          return (async function* () { yield bytes; })();
        },
      },
    });
    await result.finish({ outcome: "complete" });

    const authorFile = join(root, "main.svml");
    const runFile = join(root, "reuse.svrun");
    await writeFile(authorFile, `<?svml using="@hypit/markup@1"?>
<svml>
  <import as="media" from="example.result-reuse@1"/>
  <media:Video id="shot"/>
</svml>`, "utf8");
    await writeFile(runFile, `<?svml using="@hypit/markup/run@1"?>
<svrun version="1">
  <author source="./main.svml"/>
  <target output="shot.video"/>
  <build-record id="prior" build="bld_20260902T110000001Z_0000000001" output="shot.video"/>
  <satisfy output="shot.video" candidate="prior"/>
</svrun>`, "utf8");

    const workspace = await authorCompiler.openEntry(runFile);
    const repository = new FileBuildResultRepository(resultsRoot);
    let opens = 0;
    let resolves = 0;
    const countedRepository: FileBuildResultRepository = Object.create(repository) as FileBuildResultRepository;
    countedRepository.resolve = async (build, output) => {
      resolves += 1;
      return await repository.resolve(build, output);
    };
    countedRepository.openFile = async (build, file) => {
      opens += 1;
      return await repository.openFile(build, file);
    };
    const loaded = await loadRunFile({
      workspace,
      authorCompiler,
      frontends: [runMarkupFrontend],
      packageContributions: [],
      results: countedRepository,
    });
    const catalog = createCatalogDescriptor({ source: authorFile, compilation: loaded.author });
    assert.equal(catalog.publishedOutputs.find((output) => output.name === "shot.video")?.displayName, "shot");
    const renamed = createCatalogDescriptor({ source: authorFile, compilation: {
      ...loaded.author,
      exports: loaded.author.exports.map((output) => ({ ...output, name: `public.${output.name}` })),
    } });
    assert.equal(renamed.publishedOutputs.find((output) => output.name === "public.shot.video")?.displayName, "shot");
    const candidate = loaded.run.graph.candidates[0];
    assert.equal(candidate?.root.kind, "value");
    const value = candidate?.root.kind === "value" ? candidate.root.value.value : undefined;
    assert.equal(value?.kind, "inline");
    assert.equal(value?.kind === "inline" ? value.value : undefined, null,
      "a forward-only Candidate remains structural and is never materialized into Core");
    const logicalOutput = loaded.author.exports.find((item) => item.name === "shot.video")?.ref;
    assert.equal(logicalOutput?.kind, "logical-output");
    assert.deepEqual(loaded.compiler.planCompilation(loaded).resultForwards, [{
      output: logicalOutput!.id,
      build: "bld_20260902T110000001Z_0000000001",
      sourceOutput: "shot.video",
      type: videoType,
    }]);
    assert.equal(resolves, 0, "forward-only compilation never opens the historical value document");
    assert.equal(loaded.attachments.length, 0);
    assert.deepEqual(loaded.resultResourceReferences, {});
    const forwardedPlan = loaded.compiler.planCompilation(loaded);
    assert.equal(forwardedPlan.state.plan.steps.length, 0);
    assert.equal(forwardedPlan.state.status, "complete");
    assert.deepEqual(forwardedPlan.state.targets, []);
    assert.equal(opens, 0);

    const materializeImport = async (base: typeof loaded, build: string): Promise<typeof loaded> => {
      const [resolved, stored] = await Promise.all([
        resolveBuildResultValue(repository, build, "shot.video"),
        repository.resolve(build, "shot.video"),
      ]);
      assert(resolved !== undefined && resolved.value.kind === "inline");
      assert(stored?.value.kind === "value");
      if (stored?.value.kind !== "value") throw new Error("expected composite");
      const files = new Map<string, typeof stored.value.document.resources[number]["file"]>();
      for (const binding of stored.value.document.resources) {
        files.set(fileReferenceIdentity(stored.build, binding.file), binding.file);
      }
      const references = Object.fromEntries((resolved.attachments ?? []).map((attachment, index) => {
        const file = [...files.values()][index];
        if (file === undefined) throw new Error("resolved attachment has no Result file");
        return [attachment.artifact.resource, ownedFileReference(stored.build, file)];
      }));
      return {
        ...base,
        run: {
          ...base.run,
          graph: {
            ...base.run.graph,
            candidates: base.run.graph.candidates.map((item, index) => index === 0 && item.root.kind === "value"
              ? { ...item, root: { ...item.root, value: { ...item.root.value, value: resolved.value } } }
              : item),
          },
        },
        attachments: resolved.attachments ?? [],
        resultResourceReferences: references,
      };
    };

    // New Composite records may wrap imported values at arbitrary depth. Their Resource ownership
    // must survive multiple Builds, including a mix of old media and newly produced bytes.
    let imported = await materializeImport(loaded, "bld_20260902T110000001Z_0000000001");
    const owner = "bld_20260902T110000001Z_0000000001";
    for (const id of ["bld_20260902T110000002Z_0000000001", "bld_20260902T110000003Z_0000000001"]) {
      const rootValue = imported.run.graph.candidates[0]!.root;
      assert.equal(rootValue.kind, "value");
      if (rootValue.kind !== "value") throw new Error("expected value");
      const extra = { kind: "blob" as const, resource: `res_${id}`, size: 1, mediaType: "image/png" };
      const current = await repository.create({
        id, source: { id: authorFile }, targets: ["shot.video"],
        publishedOutputs: [{ name: "shot.video", output: "wrapped" }],
        resourceReferences: imported.resultResourceReferences,
      });
      await current.sync({
        state: { status: "complete", records: [{ id: "record:wrapped", type: videoType,
          value: { kind: "inline", value: { layers: [{ nested: rootValue.value.value }], extra } } }],
          plan: { outputBindings: [{ output: "wrapped", record: "record:wrapped", type: videoType }] },
        } as unknown as BuildState,
        resources: { async open(artifact) {
          assert.equal(artifact.resource, extra.resource, "Only genuinely new bytes may be copied");
          return (async function* () { yield new Uint8Array([7]); })();
        } },
      });
      await current.finish({ outcome: "complete" });
      assert.deepEqual(await readdir(join(current.directory, "files")), ["file-0001.png"]);
      const saved = await repository.resolve(id, "shot.video");
      assert.equal(saved?.value.kind, "value");
      if (saved?.value.kind !== "value") throw new Error("expected composite");
      const original = saved.value.document.resources.find((binding) => binding.file.mediaType === "video/mp4")!;
      assert.deepEqual(original.file, { kind: "build-file", build: owner, path: "files/file-0001.mp4", size: bytes.length, mediaType: "video/mp4" });
      const received: number[] = [];
      for await (const chunk of (await repository.openFile(id, original.file))!) received.push(...chunk);
      assert.deepEqual(Uint8Array.from(received), bytes);
      await writeFile(runFile, (await readFile(runFile, "utf8")).replace(/build="[^"]+"/, `build="${id}"`));
      imported = await materializeImport(await loadRunFile({ workspace: await authorCompiler.openEntry(runFile), authorCompiler,
        frontends: [runMarkupFrontend], packageContributions: [], results: repository }), id);
    }

    // Explicit export collects a standalone bundle, including same-named files with different owners.
    const bundle = join(root, "exported-layout");
    await jsonCommand(["get", "bld_20260902T110000003Z_0000000001", "--output", "shot.video", "--to", bundle], root);
    const exported = JSON.parse(await readFile(join(bundle, "value.json"), "utf8")) as import("@hypit/result").BuildResultValueDocument;
    assert.equal(exported.resources.length, 3);
    const exportedPaths = new Set<string>();
    for (const binding of exported.resources) {
      assert.equal(binding.file.kind, "build-file");
      if (binding.file.kind !== "build-file") throw new Error("expected local export");
      assert.equal(binding.file.build, undefined);
      exportedPaths.add(binding.file.path);
      assert.deepEqual(await readFile(join(bundle, binding.file.path)),
        binding.file.mediaType === "video/mp4" ? Buffer.from(bytes) : Buffer.from([7]));
    }
    assert.equal(exportedPaths.size, 3);

    // A file Candidate is a live address, even when republished by separate Builds.
    const externalPath = join(root, "selected.mp4");
    await writeFile(externalPath, bytes);
    await writeFile(runFile, `<?svml using="@hypit/markup/run@1"?>
<svrun version="1"><author source="./main.svml"/><target output="shot.video"/>
<file id="selected" type="example.result-reuse@1#Video" from="./selected.mp4" media-type="video/mp4"/>
<satisfy output="shot.video" candidate="selected"/></svrun>`);
    const externalRun = await loadRunFile({ workspace: await authorCompiler.openEntry(runFile), authorCompiler,
      frontends: [runMarkupFrontend], packageContributions: [], results: repository });
    assert.deepEqual(Object.values(externalRun.resultResourceReferences), [{
      kind: "external-file", uri: pathToFileURL(await realpath(externalPath)).href, size: bytes.length, mediaType: "video/mp4",
    }]);
    for (const id of ["bld_20260902T110000004Z_0000000001", "bld_20260902T110000005Z_0000000001"]) {
      const current = await repository.create({ id, source: { id: authorFile }, targets: ["shot.video"],
        publishedOutputs: [{ name: "shot.video", output: logicalOutput!.id }],
        resourceReferences: externalRun.resultResourceReferences });
      await current.sync({ state: externalRun.compiler.planCompilation(externalRun).state,
        resources: { async open() { throw new Error("External files must stay references"); } } });
      await current.finish({ outcome: "complete" });
      assert.deepEqual(await readdir(current.directory), ["result.json"]);
    }
    const externalBuild = "bld_20260902T110000005Z_0000000001";
    await writeFile(externalPath, "replacement");
    const changed = await repository.resolve(externalBuild, "shot.video");
    assert.equal(changed?.value.kind, "external-file");
    if (changed?.value.kind !== "external-file") throw new Error("expected file");
    assert.equal(changed.value.size, 11);
    const chunks: Uint8Array[] = [];
    for await (const chunk of (await repository.openFile(externalBuild, changed.value))!) chunks.push(chunk);
    assert.equal(Buffer.concat(chunks).toString(), "replacement");
    await rm(externalPath);
    await assert.rejects(repository.resolve(externalBuild, "shot.video"), /ENOENT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("Composite Result resources rebuild each shared container once", async () => {
  const count = 400;
  let visited = 0;
  class CountedArray extends Array<null> {
    override map<U>(callback: (value: null, index: number, array: null[]) => U, thisArg?: unknown): U[] {
      visited += this.length;
      return super.map(callback, thisArg);
    }
  }
  const value = new CountedArray(count).fill(null);
  const file = { kind: "build-file" as const, path: "files/one.mp4", size: 1, mediaType: "video/mp4" };
  const repository = {
    read: async () => ({ outcome: "complete" as const }),
    resolve: async () => ({ build: "owner", output: "composite", type: valueType, value: {
      kind: "value" as const,
      path: "values/value-0001.json",
      document: {
        format: "hypit.result-value@1" as const,
        value,
        resources: Array.from({ length: count }, (_, index) => ({ at: [index], file })),
      },
    } }),
    describeFile: async () => file,
    openFile: async () => undefined,
  } as unknown as import("@hypit/result").BuildResultRepository;
  const resolved = await resolveBuildResultValue(repository, "owner", "composite");
  assert.equal(resolved?.value.kind, "inline");
  assert.equal(visited, count, "the root array is rebuilt once rather than once per Resource binding");
  assert.equal(resolved?.attachments?.length, 1, "one historical file identity remains one lazy attachment");
});

test("a failed Result exposes task receipts and credential references without a Runtime", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-receipts-"));
  const id = "bld_20260906T110000000Z_0000000001";
  try {
    const result = await FileBuildResult.create(join(root, ".hypit", "results"), {
      id, source: { id: "main.svml" }, targets: [], publishedOutputs: [],
    });
    const operation = {
      operation: "op-1", command: "need-1", endpoint: "selected-account", pool: "my-pool",
      need: { id: "generation-1", capability: valueType },
      credentials: { apiKey: { store: "os", key: "personal-api-key" } },
      receipt: { id: "remote-task-1" }, status: "failed" as const,
      failure: { code: "DOWNLOAD_FAILED", message: `HTTP 502; request=req-example; ${"public reason ".repeat(35)}last diagnostic detail` },
      createdAt: 1, acknowledgedAt: 2,
    };
    await result.finish({ outcome: "failed", failure: "download failed", operations: [operation] });
    const inspected = await jsonCommand(["inspect", id], root) as {
      build: { outcome: string; operations: unknown[] };
    };
    assert.equal(inspected.build.outcome, "failed");
    assert.deepEqual(inspected.build.operations, [{
      endpoint: operation.endpoint, status: operation.status, receipt: operation.receipt, failure: operation.failure,
    }]);
    const detailed = await jsonCommand(["inspect", id, "--verbose"], root) as { build: { operations: unknown[] } };
    assert.deepEqual(detailed.build.operations, [operation]);
    const human = await humanCommand(["inspect", id], root);
    assert.match(human, /remote-task-1/);
    assert.match(human, /DOWNLOAD_FAILED/);
    assert.ok(human.includes(operation.failure.message));
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("logs reads finished evidence without a Runtime and clearly limits the tail", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-logs-"));
  try {
    const id = "bld_20260913T130000000Z_0000000001";
    const result = await FileBuildResult.create(join(root, ".hypit/results"), {
      id, source: { id: "main.svml" }, targets: [], publishedOutputs: [],
    });
    const records = ["started", "completed"].map((kind, time) => ({ format: "hypit.execution-log@1", time, kind, endpoint: "renderer", command: "c1" }));
    await result.finish({ outcome: "complete", executionLog: (async function* () {
      yield Buffer.from(records.map((record) => JSON.stringify(record) + "\n").join(""));
    })() });
    await writeFile(join(root, ".hypit/runtime"), "missing-profile.json\n");
    assert.ok((await humanCommand(["inspect", id], root)).includes(
      commandHint(["logs", id], { projectRoot: await realpath(root) }),
    ));
    assert.deepEqual(await jsonCommand(["logs", id, "--lines", "1"], root), {
      format: "hypit.cli-logs@1", build: id, source: "result", records: [records[1]], omittedRecords: 1,
    });
    assert.match(await humanCommand(["logs", id, "--lines", "1"], root), /earlier records omitted/u);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("history continuation keeps the same project and Source query", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit cli pagination "));
  try {
    const older = "bld_20260902T110000000Z_0000000001";
    const newer = "bld_20260902T110000002Z_0000000001";
    await fixture(root, older, "selected source.svml");
    await fixture(root, "bld_20260902T110000001Z_0000000001", "unrelated.svml");
    await fixture(root, newer, "selected source.svml");
    const args = ["history", "stage.value", "--source", join(root, "selected source.svml"), "--limit", "1"];
    const human = await humanCommand(args, root);
    assert.match(human, /Repeat this command with --before (\S+), keeping the other options/u);
    const cursor = /--before (\S+),/u.exec(human)![1]!;
    const next = await jsonCommand([...args, "--before", cursor], root) as { entries: { build: string }[] };
    assert.deepEqual(next.entries.map((item) => item.build), [older]);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("history through a directory alias still finds a Source after its directory is removed", async () => {
  const parent = await mkdtemp(join(tmpdir(), "hypit-history-alias-"));
  try {
    const root = join(parent, "project");
    const alias = join(parent, "shortcut");
    await mkdir(join(root, "chapter"), { recursive: true });
    await writeFile(join(root, "chapter", "main.svml"), "source");
    await symlink(root, alias, "junction");
    const id = "bld_20260902T110000000Z_0000000001";
    await fixture(root, id, "chapter/main.svml");
    await rm(join(root, "chapter"), { recursive: true });
    const history = await jsonCommand(["history", "stage.value", "--source", join(alias, "chapter", "main.svml")], alias) as {
      source: string; entries: { build: string }[];
    };
    assert.equal(history.source, join("chapter", "main.svml"));
    assert.deepEqual(history.entries.map((entry) => entry.build), [id]);
  } finally { await rm(parent, { recursive: true, force: true }); }
});

test("logs reports unavailable evidence as unsuccessful, while an existing empty log is valid", async () => {
  const root = await mkdtemp(join(tmpdir(), "hypit-cli-missing-log-"));
  try {
    const id = "bld_20260902T110000000Z_0000000001";
    for (const state of ["missing", "no-log", "empty-log"] as const) {
      if (state === "no-log") await fixture(root);
      if (state === "empty-log") {
        const result = await FileBuildResult.create(join(root, ".hypit/results"), {
          id: "bld_20260902T110000001Z_0000000001", source: { id: "main.svml" }, targets: [], publishedOutputs: [],
        });
        await result.finish({ outcome: "complete", executionLog: (async function* () {})() });
      }
      let exit = 0;
      let output = "";
      await runCli(["logs", state === "empty-log" ? "bld_20260902T110000001Z_0000000001" : id, "--project", root, "--json"], {
        write: (text) => { output += text; }, setExitCode: (code) => { exit = code; },
      }, resultDistribution());
      assert.equal(exit, state === "empty-log" ? 0 : 1);
      assert.equal(JSON.parse(output).source, state === "empty-log" ? "result" : "unavailable");
    }
  } finally { await rm(root, { recursive: true, force: true }); }
});
